﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pelota : MonoBehaviour
{
   
    private Rigidbody rig;

    [SerializeField] private float velocidad;



   private void Awake(){

       rig=GetComponent<Rigidbody>();
   }


    void Update()
    {
       float horizontal = Input.GetAxis("Horizontal");
      
       float vertical= Input.GetAxis("Vertical");
       rig.AddForce(new Vector3(horizontal, 0, vertical) * velocidad * Time.deltaTime);
    }
}
